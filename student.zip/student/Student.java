import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Student
{
    public static void main(String[] args)
    {

    	readJsonFile();

    }

    public static void readJsonFile() {

        BufferedReader br = null;
        JSONParser parser = new JSONParser();

        try {

            String sCurrentLine;

            br = new BufferedReader(new FileReader("Students.json"));

            while ((sCurrentLine = br.readLine()) != null) {
                System.out.println("---------------------------");

                Object obj;
                try {
                    obj = parser.parse(sCurrentLine);
                    JSONObject jsonObject = (JSONObject) obj;

                    String StudentID = (String) jsonObject.get("StudentID");
                    System.out.println(StudentID);

                    
                    String FirstName = (String) jsonObject.get("FirstName");
                    System.out.print(FirstName + " ");
                    
		
		            String LastName = (String) jsonObject.get("LastName");
                    System.out.println(LastName);
                    

                    String SSemester = (String) jsonObject.get("SSemester");
                    int Semester=Integer.parseInt(SSemester);
                    System.out.println("Semester:" + Semester);






                } catch (ParseException e) {
                    
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }
}

