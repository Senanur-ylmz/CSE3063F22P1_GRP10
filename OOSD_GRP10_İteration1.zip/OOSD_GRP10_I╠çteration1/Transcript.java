import java.util.ArrayList;
import java.io.IOException;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Transcript extends Course {

    private String Transcript_ID;
    private double GPA;
    private int TotalCredit;
    private int CompletedCredit;
    private int Semester;
    private String Student_ID;

    private ArrayList<Course> allCourses = new ArrayList<>();

    public Transcript(String Transcript_ID, double GPA, int TotalCredit, int CompletedCredit, int Semester, String Student_ID){
        this.Transcript_ID=Transcript_ID;
        this.GPA=GPA;
        this.TotalCredit=TotalCredit;
        this.CompletedCredit=CompletedCredit;
        this.Semester=Semester;
    }

    public Transcript() {
    }

    public double getGPA(){
        return this.GPA;
    }

    public String getStudent_ID(){
        return this.Student_ID;
    }

    public int getSemester(){
        return this.Semester;
    }

    public double calculateTotalCredit(){
        return this.TotalCredit;
    }

    public ArrayList<Course> FailedCourses(){
        ArrayList<Course> failedCourses = new ArrayList<>();

        for (Course course:this.allCourses){
            if(course.getGrade() < 35){
                failedCourses.add(course);
            }
        }
        return failedCourses;
    }

    public ArrayList<Course> PassedCourses(){
        ArrayList<Course> passedCourses = new ArrayList<>();

        for (Course course:this.allCourses){
            if(course.getGrade() >= 35){
                passedCourses.add(course);
            }
        }
        return passedCourses;
    }

}


