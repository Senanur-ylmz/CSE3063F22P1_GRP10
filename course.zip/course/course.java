import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class course
{
    public static void main(String[] args)
    {

    	readJsonFile();

    }

    public static void readJsonFile() {

        BufferedReader br = null;
        JSONParser parser = new JSONParser();

        try {

            String sCurrentLine;

            br = new BufferedReader(new FileReader("courses.json"));

            while ((sCurrentLine = br.readLine()) != null) {
                System.out.println("---------------------------");

                Object obj;
                try {
                    obj = parser.parse(sCurrentLine);
                    JSONObject jsonObject = (JSONObject) obj;

                    String CourseCode = (String) jsonObject.get("CourseCode");
                    System.out.println(CourseCode);

                    
                    String CourseName = (String) jsonObject.get("CourseName");
                    System.out.println(CourseName);


                    String credit = (String) jsonObject.get("Credit");
                    int Credit=Integer.parseInt(credit);
                    System.out.println("Credit:"+Credit);


                    String PrerequisiteCourseCodes = (String) jsonObject.get("PrerequisiteCourseCodes");
                    System.out.println("Prerequisite: " + PrerequisiteCourseCodes);
                    

                    String CourseType = (String) jsonObject.get("CourseType");
                    System.out.println("CourseType: "+CourseType);


                } catch (ParseException e) {
                    
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }
}

