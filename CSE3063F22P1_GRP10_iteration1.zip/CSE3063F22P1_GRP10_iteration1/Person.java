public class Person {
          public String FullName;
          public String email;
  
          
          public String getName(){
            return FullName;
        
        }
        
        public String getEmail(){
            return email;
        }



      }
      
  

