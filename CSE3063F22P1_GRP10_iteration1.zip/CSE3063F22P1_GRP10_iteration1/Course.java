import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Course
{
    //variables
    private String CourseCode;
    private String CourseName;
    private Integer Credit;
    private String PrerequisiteCourseCodes;
    private String CourseType;

    //a constructor for objects
    public Course(String CourseCode, String CourseName, Integer Credit, String PrerequisiteCourseCodes, String CourseType){
    	
        //making variables readable from other classes and functions
    	this.CourseCode = CourseCode;
    	this.CourseName = CourseName;
    	this.Credit = Credit;
        this.PrerequisiteCourseCodes = PrerequisiteCourseCodes;
    	this.CourseType = CourseType;
    }


    public static void main(String[] args)
    {

    	readJsonFile();

    }
    //adding all courses into array list to take from .json file
    public static void readJsonFile() {

        BufferedReader br = null;
        JSONParser parser = new JSONParser();

        try {

            String sCurrentLine;

            br = new BufferedReader(new FileReader("courses.json"));

            while ((sCurrentLine = br.readLine()) != null) {
                System.out.println("---------------------------");

                Object obj;
                try {
                    obj = parser.parse(sCurrentLine);
                    JSONObject jsonObject = (JSONObject) obj;

                    String CourseCode = (String) jsonObject.get("CourseCode");
                    System.out.println(CourseCode);

                    
                    String CourseName = (String) jsonObject.get("CourseName");
                    System.out.println(CourseName);


                    String credit = (String) jsonObject.get("Credit");
                    int Credit=Integer.parseInt(credit);
                    System.out.println("Credit:"+Credit);


                    String PrerequisiteCourseCodes = (String) jsonObject.get("PrerequisiteCourseCodes");
                    System.out.println("Prerequisite: " + PrerequisiteCourseCodes);
                    

                    String CourseType = (String) jsonObject.get("CourseType");
                    System.out.println("CourseType: "+CourseType);


                } catch (ParseException e) {
                    
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }

    //getter and setters of variables
    public String getCourseCode() {
		return CourseCode;
	}
	public void getCourseCode(String courseCode) {
		CourseCode = courseCode;
    }
    
    public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}

    public int getCredit() {
		return Credit;
	}

	public void setCredit(int credit) {
		Credit = credit;
	}
    
    public String getPrerequisiteCourseCodes() {
		return PrerequisiteCourseCodes;
	}
	public void setPrerequisiteCourseCodes(String pCode) {
		PrerequisiteCourseCodes = pCode;
	}

    public String getCourseType() {
		return CourseType;
	}

	public void setCourseType(String cType) {
		CourseType = cType;
	}
}

