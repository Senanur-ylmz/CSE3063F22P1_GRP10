import java.io.IOException;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileNotFoundException;
import java.io.FileReader;


public class Student {
	
	//variables
	private String StudentID;
	private String FirstName;
	private String LastName;
    	private int SSemester;
	
    //a constructor for objects
    public Student(String StudentID, String FirstName, String LastName, int SSemester){
    	
    	//making variables readable from other classes and functions
    	this.StudentID = StudentID;
    	this.FirstName = FirstName;
    	this.LastName = LastName;
    	this.SSemester = SSemester;
    }
   
    
    //adding all students into array list to take from file
    public static void addStudent() throws FileNotFoundException, IOException, ParseException {

    	//Reading JSON file
    	Object obj = new JSONParser().parse(new FileReader("Students.json"));
        JSONObject jo = (JSONObject) obj;

        String StudentID = (String) jo.get("StudentID");
        String FirstName = (String) jo.get("FirstName");
        String LastName = (String) jo.get("LastName");
        String SSemester = (String) jo.get("SSemester");;
        JSONArray PassedCourses = (JSONArray) jo.get("PassedCourses");
        JSONArray FailedCourses = (JSONArray) jo.get("FailedCourses");

        System.out.println(StudentID+"  "+FirstName+" "+LastName);
        System.out.println("Semester:"+SSemester);
        System.out.println("PassedCourses:"+PassedCourses);
        System.out.println("FailedCourses:"+FailedCourses);
        
    }
    
    
    //taking transcript information of a student
    public void getTranscript() {
    	
    	//creating transcript object to hold informations
    	Transcript studentTranscript = new Transcript();
    	StudentID = studentTranscript.getStudentID();
    	SSemester = studentTranscript.addSemester();
    	
    }

    
    //getter and setters of variables
	public String getStudentID() {
		return StudentID;
	}
	public void setStudentID(String studentID) {
		StudentID = studentID;
	}

	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}


	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public int getSemester() {
		return SSemester;
	}
	public void setSemester(int semester) {
		SSemester = semester;
	}

	
	//main function to display
    public static void main(String[] args) throws Exception{
    	addStudent();
    	
    }
}
