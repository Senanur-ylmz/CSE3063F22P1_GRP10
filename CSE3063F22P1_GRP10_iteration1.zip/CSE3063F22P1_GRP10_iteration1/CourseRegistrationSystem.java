public class CourseRegistrationSystem {
          public void setTotalCredit(){
      
          }
          public void setQuota(){
      
          }
          public void LogDetails(){
              
          }
      }
      