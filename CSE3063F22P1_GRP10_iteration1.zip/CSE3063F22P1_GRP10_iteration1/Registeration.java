
public class Registeration {
       public boolean approved;
       public int student;
       public String ccode;
       
       public Registeration (boolean approved) {
    	   this.approved=approved;
       }
       
       public void enrollStudentForCourses(String stdid, String coursecode) {
    	//    Student std = new Student(stdid,stdfname,stdlname,ssemester);
    	//   Course course = new Course();
       }
       
       public void getStudentDetail(String stdid,String stdfname, String stdlname,int ssemester) {
    	   Student std = new Student(stdid,stdfname,stdlname,ssemester);
    	   std.getFirstName();
    	   std.getLastName();
    	   std.getSemester();
    	   std.getStudentID();
    	   std.getTranscript();
       }
       
       public void getCourseDetail() {
    	   
       }
       
       public boolean checkPre() {
    	   
    	 //  if(!(std.getTranscript().PassedCourses().contains(course.Pre))) gives prerequisite error
    	   return true;
       }
       
       public boolean checkSemester() {
    	   
    	//   if(std.getSemester()<3) AND course is TE it will gives the error
    	//   if(std.getSemester() % getCourseSemester() == 0 
    	   return true;
       }
       
       public boolean checkQuota() {
    	  // if(course.getQuota()<=0) gives quota error
    	   return true;
       }

       
       public boolean checkComplitedCredit() {
    	   return true;
       }
       
       public boolean checkDate() {
    	   return true;
       }
       
       public boolean isApproved() {
    	   return approved;
       }


}

